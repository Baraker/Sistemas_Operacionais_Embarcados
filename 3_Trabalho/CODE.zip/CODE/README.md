# Projeto Police VR Code

Para facilitar a compilação e debug utilizamos o Cmake.

> $ rm -r Build 
> 
> $ mkdir Build
> 
> $ cd Build 
> 
> $ cmake ..
> 
> $ make
> 
> $ sudo ./PoliceVR
> 